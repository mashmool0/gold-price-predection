def nums():
    verify = input('enter : ')
    if verify == 'a' : 
        return 5, 2, 3,
    else : 
        print('noo')


())
print(a, b, c)
