import datetime 

start = datetime.date(2023,9,29)
end = datetime.date(2007,7,2)

print((start-end).days)
